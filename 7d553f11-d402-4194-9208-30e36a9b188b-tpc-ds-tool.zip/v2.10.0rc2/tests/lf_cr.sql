insert into catalog_returns (select * from crv);
rollback;
